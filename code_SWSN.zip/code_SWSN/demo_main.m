% The files are the MATLAB demo code for the paper: 
% Joint Spatial-frequency Scattering Network for Unsupervised SAR Image Change Detection
% Please cite our paper if you find the code useful

clear;
clc;
close all;
t1 = clock;
addpath('./Utils');

PatSize = 7;
k_n = 3;

im1   = load('yellow1_1.mat');
im2   = load('yellow1_2.mat');
im_gt = load('yellow1_gt.mat');

im1 = double(im1.data(:,:,1));
im2 = double(im2.data(:,:,1));
im_gt = double(im_gt.im_gt(5:295,5:310,1)-1);

fprintf(' ... ... read image file finished !!! !!!\n\n');


[ylen, xlen] = size(im1);

% compute the neighborhood-based ratio image
fprintf(' ... .. compute the neighborhood ratio ..\n');
nrmap = nr(im1, im2, k_n);
nrmap = max(nrmap(:))-nrmap;
nrmap = nr_enhance( nrmap );
feat_vec = reshape(nrmap, ylen*xlen, 1);
fprintf(' ... .. compute finished !!! !!! !!! !!!!\n\n');

fprintf(' ... .. clustering for sample selection begin ... ....\n');
im_lab = gao_clustering(feat_vec, ylen, xlen);
fprintf(' ... .. clustering for sample selection finished !!!!!\n\n');

fprintf(' ... ... ... samples initializaton begin ... ... .....\n');
fprintf(' ... ... ... Patch Size : %d pixels ... ....\n', PatSize);


pos_lab = find(im_lab == 1);
neg_lab = find(im_lab == 0);

pos_lab = pos_lab(randperm(numel(pos_lab)));
neg_lab = neg_lab(randperm(numel(neg_lab)));

[ylen, xlen] = size(im1);

mag = (PatSize-1)/2;
imTmp = zeros(ylen+PatSize-1, xlen+PatSize-1);
imTmp((mag+1):end-mag,(mag+1):end-mag) = im1; 
im1 = im2col_general(imTmp, [PatSize, PatSize]);
imTmp((mag+1):end-mag,(mag+1):end-mag) = im2; 
im2 = im2col_general(imTmp, [PatSize, PatSize]);
clear imTmp mag;

% merge samples to im
im1 = mat2imgcell(im1, PatSize, PatSize, 'gray');
im2 = mat2imgcell(im2, PatSize, PatSize, 'gray');
parfor idx = 1 : numel(im1)
    im_tmp = [im1{idx}; im2{idx}];
    im(idx, :) = im_tmp(:);
end
clear im1 im2 idx;

fprintf(' ... ... ... randomly generation samples ... ... .....\n');
PosNum = numel(pos_lab);
NegNum = numel(neg_lab);



PosPat = im(pos_lab(1:PosNum), :);
NegPat = im(neg_lab(1:NegNum), :);
TrnPat = [PosPat; NegPat];
TrnLab = [ones(PosNum, 1); zeros(NegNum, 1)];
trn_data = [TrnLab, TrnPat];
clear PosPat NegPat TraPat TrnLab; 
clear PosNum NegNum;
clear pos_lab neg_lab;

TstLab = ones(size(im,1), 1);
tst_data = [TstLab, im];

fprintf(' ============== Extreme Learning Machine begin ========\n');
%-----------------------------------------------------
trn_accu = elm_train(trn_data, 1, 200, 'sig');% 300 /200/
elm_out = elm_predict(tst_data);


elm_out = reshape(elm_out, [ylen, xlen]);
idx = find(im_lab == 1);
elm_out(idx) = 1;
idx = find(im_lab == 0);
elm_out(idx) = 0;

clear trn_data tst_data trn_accu;
clear ylen xlen;

[elm_out,num] = bwlabel(~elm_out);
for i = 1:num
    idx = find(elm_out==i);
    if numel(idx) <= 10
        elm_out(idx)=0;
    end
end
elm_out = elm_out>0;
clear i num TrnPat TstLab NumSam;

im_gt1 = im_gt*255;
elm_out1 = elm_out*255;

[FA,MA,OE,CA,KCC] = evaluate_g(im_gt1, elm_out1);
% Save change detection results
fprintf('FALSE ALRAMS : %d \n', FA);
fprintf('MISSED PIXEL : %d \n', MA);
fprintf('OVERALL ERROR: %d \n', OE);
fprintf('PCC          : %f \n', CA);
fprintf('KCC          : %f \n\n\n', KCC);


figure
imagesc(elm_out)
colormap(gray)
axis off

%% scattering part definition
im1   = load('yellow1_1.mat');
im2   = load('yellow1_2.mat');
im_gt = load('yellow1_gt.mat');

im1 = double(im1.data(:,:,1));
im2 = double(im2.data(:,:,1));
im_gt = double(im_gt.im_gt(5:295,5:310,1)-1);


[ylen, xlen] = size(im1);


cutoff1 = norm(im1,'fro')*.02;
cutoff2 = norm(im2,'fro')*.02;


filt_opt.J = 2;
filt_opt.L = 96;% parallel broad scattering parameters
scat_opt.M = 1;
scat_opt.oversampling = 2;
filt_opt.filter_type = 'stockwell';
filt_opt.chirp_rate = 2.7; 
filt_opt.basis = -0.2;


%% scattering operation
[Wop, filters] = stockwell_factory_2d(size(im1), filt_opt, scat_opt);


[SST1,newU1,newV1] = scatNew(im1,Wop);
[SST_mat1,SST_meta1] = format_scat(SST1);
SST_mat1 = double(SST_mat1);

%% find proper coefficients for im1
SST_j_thres1 = [];
SST_theta_thres1 = [];
SST_thres1 = [];
for k = 1:size(SST_mat1,1)
    if norm(squeeze(SST_mat1(k,:,:)),'fro') >= cutoff1
        SST_thres1 = cat(3,SST_thres1,squeeze(SST_mat1(k,:,:)));
        SST_j_thres1 = [SST_j_thres1, SST_meta1.j(:,k)];
        SST_theta_thres1 = [SST_theta_thres1, SST_meta1.theta(:,k)];
    end
    k;
end

[SST2,newU2,newV2] = scatNew(im2,Wop);
[SST_mat2,SST_meta2] = format_scat(SST2);
SST_mat2 = double(SST_mat2);

%% find propoer coefficients for im2
SST_j_thres2 = [];
SST_theta_thres2 = [];
SST_thres2 = [];
for k = 1:size(SST_mat2,1)
    if norm(squeeze(SST_mat2(k,:,:)),'fro') >= cutoff2
        SST_thres2 = cat(3,SST_thres2,squeeze(SST_mat2(k,:,:)));
        SST_j_thres2 = [SST_j_thres2, SST_meta2.j(:,k)];
        SST_theta_thres2 = [SST_theta_thres2, SST_meta2.theta(:,k)];
    end
    k;
end


pixel_vector1 = reshape(SST_thres1, ylen*xlen, size(SST_thres1,3)); % transfer to one column
pixel_vector2 = reshape(SST_thres2, ylen*xlen, size(SST_thres2,3)); % transfer to one column
pixel_gt = reshape(im_gt, ylen*xlen, 1);


clustering_gt = reshape(double(elm_out), ylen*xlen, 1);

pos_idx = find(clustering_gt == 1); % get the position
neg_idx = find(clustering_gt == 0);


rand('seed', 2);
pos_idx = pos_idx(randperm(numel(pos_idx)));
neg_idx = neg_idx(randperm(numel(neg_idx)));

%% use percentage to show the result

train_num_pos =3000;
train_num_neg =3000;

SST_data = [pixel_vector1 pixel_vector2];
SST_label = pixel_gt;

train_data = [SST_data(pos_idx(1:train_num_pos),:);SST_data(neg_idx(1:train_num_neg),:)];
train_label = [clustering_gt(pos_idx(1:train_num_pos),:);clustering_gt(neg_idx(1:train_num_neg),:)];
train_gt = [SST_label(pos_idx(1:train_num_pos),:);SST_label(neg_idx(1:train_num_neg),:)];



test_data = [SST_data(1:end,:)];
test_label = [SST_label(1:end,:)];


%% SVM

model = svmtrain(train_label, train_data);

model;
Parameters = model.Parameters;
Label = model.Label;
nr_class = model.nr_class;
totalSV = model.totalSV;
nSV = model.nSV ;


[predictlabel] = svmpredict(test_label, test_data,model);
predictlabel = predictlabel*255;
test_label = test_label*255;

[FA,MA,OE,CA,KCC] = evaluate_g(test_label, predictlabel);% get the accuracy ratio
fprintf('FALSE ALRAMS : %d \n', FA);
fprintf('MISSED PIXEL : %d \n', MA);
fprintf('OVERALL ERROR: %d \n', OE);
fprintf('PCC          : %f \n\n\n', CA);
fprintf('KCC          : %f \n\n\n', KCC);


figure
vis_map = reshape(predictlabel,ylen,xlen);
imagesc(vis_map)
colormap(gray)
title(['J = ',num2str(filt_opt.J),', L = ',num2str(filt_opt.L),', M = ',num2str(scat_opt.M),', OA = ',num2str(CA)]);



%% train 2
%% SVM
%fprintf(' ... ... start training !!! !!!\n\n');
rand('seed', 2);
pos_idx = pos_idx(randperm(numel(pos_idx)));
neg_idx = neg_idx(randperm(numel(neg_idx)));

train_num_pos =3000;
train_num_neg =3000;


clustering_gt2 = predictlabel/255;

train_data = [SST_data(pos_idx(1:train_num_pos),:);SST_data(neg_idx(1:train_num_neg),:)];
train_label2 = [clustering_gt2(pos_idx(1:train_num_pos),:);clustering_gt2(neg_idx(1:train_num_neg),:)];


model = svmtrain(train_label2, train_data);

model;
Parameters = model.Parameters;
Label = model.Label;
nr_class = model.nr_class;
totalSV = model.totalSV;
nSV = model.nSV ;


[predictlabel] = svmpredict(test_label, test_data,model);
predictlabel = predictlabel*255;
test_label = test_label*255;

[FA,MA,OE,CA,KCC] = evaluate_g(test_label, predictlabel);% get the accuracy ratio
fprintf('FALSE ALRAMS : %d \n', FA);
fprintf('MISSED PIXEL : %d \n', MA);
fprintf('OVERALL ERROR: %d \n', OE);
fprintf('PCC          : %f \n\n\n', CA);
fprintf('KCC          : %f \n\n\n', KCC);


figure
vis_map = reshape(predictlabel,ylen,xlen);
imagesc(vis_map)
colormap(gray)
title(['J = ',num2str(filt_opt.J),', L = ',num2str(filt_opt.L),', M = ',num2str(scat_opt.M),', OA = ',num2str(CA)]);

t2 = clock;
etime(t2,t1)
